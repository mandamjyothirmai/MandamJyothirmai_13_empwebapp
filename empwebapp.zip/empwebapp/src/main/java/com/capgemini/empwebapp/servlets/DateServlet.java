package com.capgemini.empwebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DateServlet extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	//super.doGet(req, resp);
	Date currentDate=new Date(0);
	resp.setHeader("Refresh", "1");
	
	PrintWriter out=resp.getWriter();
	out.print("<html>");
	out.print("<body>");
	out.println("<h1>Current system Date & Time is-"+ currentDate +"</h1>");
	out.print("</body>");
	out.print("</html");
}//end of do get
}// endof the class
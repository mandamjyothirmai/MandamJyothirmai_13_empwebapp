package com.capgemini.empwebapp.dao;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.ArrayList;
	import java.util.List;

	import com.capgemini.empwebapp.dto.EmployeeInfoBean;

	public class EmployeeDAOJDBCImpl implements EmployeeDAO{
	 Connection connection= null;
	 
	 static {
	 try {
	 Class.forName("com.mysql.jdbc.Driver").newInstance();
	 String url="jdbc:mysql://localhost:3306/test?user=root&password=root";
	 }catch(Exception e) {
	 e.printStackTrace();
	 }
	 
	 }
	 public EmployeeInfoBean authenticate(int empId, String password) {
	EmployeeInfoBean employeeInfoBean = getEmployee(empId);
	if(!(employeeInfoBean !=null && employeeInfoBean.getPassword().equals(password))) {
	 employeeInfoBean = null;
	}
	return null;
	 }
	public EmployeeInfoBean getEmployee(int empId) {
	EmployeeInfoBean employeeInfoBean = null;
	if(connection != null) {
	PreparedStatement  pstmt = null;
	ResultSet rs = null;
	try {
	pstmt = connection.prepareStatement("select * from employee_info where empId=?");
	pstmt.setInt(1,empId);
	rs=pstmt.executeQuery();
	if(rs.next()) {
	employeeInfoBean = new EmployeeInfoBean();
	employeeInfoBean.setEmpId(rs.getInt("empId"));
	employeeInfoBean.setAge(rs.getInt("age"));
	employeeInfoBean.setEmpName(rs.getString("name"));
	employeeInfoBean.setDesignation(rs.getString("designation"));
	employeeInfoBean.setPassword(rs.getString("password"));
	employeeInfoBean.setSalary(rs.getDouble("salary"));
	}
	}catch (Exception e) {
	e.printStackTrace();
	}finally {
	if(rs!=null) {
	try {
	rs.close();
	}catch (Exception e) {
	e.printStackTrace();
	}
	}
	if(pstmt!=null) {
	try {
	pstmt.close();
	}catch (Exception e) {
	e.printStackTrace();
	}
	}
	}

	}

	return employeeInfoBean;
	}

	public boolean addEmployee(EmployeeInfoBean employeeIngoBean) {
	boolean isAdded = false ;
	if(connection != null) {
	try(PreparedStatement pstmt = connection.prepareStatement("insert into test.employee_Info values(?,?,?,?,?,?)")) {

	pstmt.setInt(1, employeeIngoBean.getEmpId());
	pstmt.setString(2,employeeIngoBean.getEmpName());
	pstmt.setInt(3, employeeIngoBean.getAge());
	pstmt.setDouble(4, employeeIngoBean.getSalary());
	pstmt.setString(5, employeeIngoBean.getDesignation());
	pstmt.setString(6, employeeIngoBean.getPassword());

	int result = pstmt.executeUpdate();

	if(result>0) {
	        System.out.println("values are inserted succefully");
	        isAdded= true;
	}
	} catch (Exception e1) {
	e1.printStackTrace();
	}

	}

	return isAdded;
	}

	public boolean updateEmployee(EmployeeInfoBean employeeInfoBean) {
	EmployeeInfoBean employeeInfoBean2 = null;
	boolean isUpdated = false ;
	if(connection != null) {

	try(PreparedStatement pstmt1 = connection.prepareStatement("update test.employee_Info set EmpName=? where EmpId=?")) {

	pstmt1.setString(1,employeeInfoBean2.getEmpName());
	pstmt1.setInt(2, employeeInfoBean2.getEmpId());

	int result = pstmt1.executeUpdate();
	if(result>0) {
	        System.out.println("values are updated succefully");
	        isUpdated= true;
	}
	} catch (Exception e1) {
	e1.printStackTrace();
	}

	}

	return isUpdated;
	     }

	public boolean deleteEmployee(int empId) {
	EmployeeInfoBean employeeInfoBean2 = null;
	boolean isDeleted = false ;
	if(connection != null) {

	try(PreparedStatement pstmt1 = connection.prepareStatement("delete from  test.employee_Info  where EmpId=?")) {


	pstmt1.setInt(1, employeeInfoBean2.getEmpId());

	int result = pstmt1.executeUpdate();
	if(result>0) {
	System.out.println("values deleted succefully");
	isDeleted= true;
	}
	} catch (Exception e1) {
	e1.printStackTrace();
	}

	}
	return isDeleted;
	}

	 
	public List<EmployeeInfoBean> getAllEmployees() {
	List<EmployeeInfoBean>   listInfo=  new ArrayList<EmployeeInfoBean>();


	ResultSet rs = null;

	if(connection != null) {
	try(PreparedStatement pstmt1 = connection.prepareStatement("select * from employee_Info")) {
	rs = pstmt1.executeQuery();

	while(rs.next()) {
	EmployeeInfoBean bean2 = new EmployeeInfoBean();

	bean2.setEmpName(rs.getString("name"));
	bean2.setAge(rs.getInt("Age"));
	bean2.setPassword(rs.getString("password"));
	bean2.setDesignation(rs.getString("designation"));
	bean2.setSalary(rs.getDouble("salary"));
	bean2.setEmpId(rs.getInt("empId"));

	listInfo.add(bean2);
	}
	}catch (Exception e) {
	e.printStackTrace();
	}finally {
	if(rs!=null) {
	try {
	rs.close();
	}catch (Exception e) {
	e.printStackTrace();
	}
	}

	}


	return listInfo;

	}
	return listInfo;
	}
	}





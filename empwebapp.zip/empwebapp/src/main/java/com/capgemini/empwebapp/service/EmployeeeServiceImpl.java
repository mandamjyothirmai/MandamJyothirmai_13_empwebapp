package com.capgemini.empwebapp.service;



	import java.util.List;


	import com.capgemini.empwebapp.dao.EmployeeDAO;
	import com.capgemini.empwebapp.dao.EmployeeDAOJDBCImpl;
	import com.capgemini.empwebapp.dto.EmployeeInfoBean;

	public class EmployeeeServiceImpl implements EmployeeService{
	    EmployeeDAO employeeDAO = new EmployeeDAOJDBCImpl();
	   
	   public EmployeeInfoBean authenticate(int empId,String password) {
	    if(empId<1 || password== null || password.trim().isEmpty()) {
	    return null;
	   
	    }
	    return employeeDAO.authenticate(empId,password);
	    }

	public EmployeeInfoBean getEmployee(int empId) {
	if(empId>0) {
	return employeeDAO.getEmployee(empId);
	}
	return null;
	}

	public boolean addEmployee(EmployeeInfoBean employeeIngoBean) {
	if(employeeIngoBean != null) {
	return employeeDAO.addEmployee(employeeIngoBean);
	}
	return false;
	}

	public boolean updateEmployee(EmployeeInfoBean employeeInfoBean) {
	// TODO Auto-generated method stub
	return employeeDAO.updateEmployee(employeeInfoBean);
	}

	public boolean deleteEmployee(int empId) {
	// TODO Auto-generated method stub
	return employeeDAO.deleteEmployee(empId);
	}

	public List<EmployeeInfoBean> getAllEmployees() {
	// TODO Auto-generated method stub
	return employeeDAO.getAllEmployees();
	}

	}

